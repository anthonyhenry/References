// do ... while loop.
#include <iostream>
#include <string>

int main()
{   
    do
    {
        std::cout << "Hello World!";
    }
    while (false);
    
    return 0;
}

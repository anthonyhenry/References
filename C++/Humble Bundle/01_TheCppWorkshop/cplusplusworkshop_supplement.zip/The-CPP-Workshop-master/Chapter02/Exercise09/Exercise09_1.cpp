// While loop.
#include <iostream>

#include <string>

int main() {
  while (false) {
    std::cout << "Hello World!";
  }

  return 0;
}
